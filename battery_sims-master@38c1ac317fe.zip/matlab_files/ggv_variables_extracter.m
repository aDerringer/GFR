clear, clc, close all

load('18e_fsi_endurance_raw.mat')

save('ggv_data', 'G_Lat_from_GPS', 'G_Long_from_GPS', 'GPS_Speed')